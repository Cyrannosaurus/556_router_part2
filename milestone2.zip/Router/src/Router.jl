module Router
using DataStructures, Graphs, StaticArrays, Base.Threads

struct Net
	id::UInt32
	pins :: Vector{UInt32}
	route_cost :: Base.Ref{UInt32}
	route :: Base.Ref{Set{BitSet}}
end

mutable struct EdgeData
	max_capacity :: UInt8
	@atomic used_capacity :: UInt16
	overflow_history :: UInt8
end

struct Chip
	size :: Tuple{UInt32, UInt32}
	default_capacity :: UInt8
	num_nets :: UInt32
	graph :: SimpleGraph{UInt32}
	capacities :: Dict{BitSet, EdgeData}
	nets :: Vector{Net}
end

use_net_decomp = true
use_net_ordering = true

function GenerateRectangularGraph(chip_size::Tuple{T, T})::SimpleGraph{T} where T <: Integer
	g = SimpleGraph(chip_size[1] * chip_size[2])
	# Add horizontal edges
	current_position = 2
	for _ in 2:chip_size[2]+1
		for _ in 1:chip_size[1]-1
			add_edge!(g, current_position, current_position-1)
			current_position += 1
		end
		current_position+=1
	end

	# Add vertical edges
	current_position = 1
	for _ in 1:chip_size[1] 
		for _ in 1:chip_size[2]-1
			@inbounds add_edge!(g, current_position, current_position + chip_size[1])
			current_position+=1
		end
	end
	g
end

@inline function ParseEdgeCapacity(edge_definition::Vector{T}, chip_size::Tuple{T, T})::BitSet where T <: Integer
	@inbounds p₁ = edge_definition[1] + edge_definition[2] * chip_size[1]
	@inbounds p₂ = edge_definition[3] + edge_definition[4] * chip_size[1]
	return BitSet((p₁, p₂))
end

function Parse(filename::String)::Chip
	lines = readlines(filename)
	
	chip_size = Tuple(parse.(UInt32, split(lines[1])[2:3]))
	default_capacity = parse(UInt8, split(lines[2])[2])
	num_nets = parse(UInt32, split(lines[3])[3])
	capacities = Dict{BitSet, EdgeData}()
	
	nets = Vector{Net}()
	num_pins :: Int32 = -1
	net = nothing
	capacities_start_index = 0
	
	@inbounds for (index, line) ∈ enumerate(view(lines, 4:length(lines)))
		split_line = split(line)

		# Is the first character an 'n' and the second character a number?
		integers = BitSet(48:57)
		if split_line[1][1] == 'n' && Int(split_line[1][2]) ∈ integers
			if num_pins == 0
				push!(nets, net)
			end
			num_pins = parse(Int32, split_line[2])
			net = Net(parse(UInt32,split_line[1][2:end]), Vector{UInt32}(), UInt32(0), Ref{Set{BitSet}}())
			continue
		end
		
		if num_pins > 0
			point = (parse(UInt32, split_line[1]), parse(UInt32, split_line[2]))
			push!(net.pins, ConvertPointToNode(point, chip_size))
		elseif num_pins == 0
			push!(nets, net)
		end
		if length(split_line) == 1
			capacities_start_index = index + 4
		end
		num_pins -= 1
	end
	for line ∈ view(lines, capacities_start_index:length(lines))
		split_line = parse.(UInt32, split(line))
		capacities[ParseEdgeCapacity(split_line, chip_size)] = EdgeData(split_line[end], split_line[end], convert(UInt8,1))
	end
	graph = GenerateRectangularGraph(chip_size)
	return Chip(chip_size, default_capacity, num_nets, graph, capacities, nets)
end

function Backtrack!(start::T, target::T, trace::AbstractDict{T,T}, chip::Chip):: Vector{BitSet} where T <: Integer

	path = Vector{BitSet}()
	current = target

	@inbounds while current != start
		used_edge = BitSet((current, trace[current]))
		edge = get!(chip.capacities, used_edge, EdgeData(chip.default_capacity, UInt16(0), convert(UInt8,1)))
		@atomic edge.used_capacity += UInt16(1)
		push!(path, used_edge)
		current = trace[current]
	end

	return path
end

function CalculateDistance(current::T, target::T, chip_size::Tuple{T, T})::UInt16 where T <: Integer
	c = convert.(Int, fldmod(current - T(1), chip_size[1]))
	t = convert.(Int, fldmod(target - T(1), chip_size[1]))
	return sum(abs.(c .- t))
end

@inline function ConvertPointToNode(p::Tuple{T,T}, chip_size::Tuple{T,T})::T where T <: Integer
	return @inbounds p[1] + 1 + p[2] * chip_size[1]
end

@inline function ConvertNodeToPoint(node::T, chip_size::Tuple{T,T})::Tuple{T, T} where T <: Integer
	@inbounds (x, y) = fldmod(node - T(1), chip_size[1])
	(y, x)
end

function ClosestPair(subnet₁::Vector{T}, subnet₂::Vector{T}, chip_size::Tuple{T,T})::SVector{2, T} where T <: Integer
	
	best = typemax(T)
	best_pair = SA[0,0]
	
	for p₁ in subnet₁
		for p₂ in subnet₂
			distance = CalculateDistance(p₁, p₂, chip_size)
			if (distance < best)
				best = distance
				best_pair = SA[p₁, p₂]
			end
		end
	end

	return best_pair
end
# Can this be done without converting to 2D?
function GenerateMinimumBoundingBox(points::SVector{2, T}, chip_size::Tuple{T,T})::Vector{T} where T <:Integer
	(x₁, y₁) = ConvertNodeToPoint(points[1], chip_size)
	(x₂, y₂) = ConvertNodeToPoint(points[2], chip_size)

	p₃ = ConvertPointToNode((x₁, y₂), chip_size)
	p₄ = ConvertPointToNode((x₂, y₁), chip_size)
	@inbounds unique = BitSet((points[1], points[2], p₃, p₄))
	return 	collect(unique)
end

# Return the sorted order of pins
# TODO: Make copy instead of doing inplace
# This means change Net to reference pins
function OrderNet!(net::Net, chip_size::Tuple{T,T}) where T <: Integer
	start = rand(net.pins)
	ordering = Vector{T}()
	sizehint!(ordering, length(net.pins))
	bb = [start]
	
	@inbounds for _ in 1:length(net.pins)
		closest_pair = ClosestPair(bb, net.pins, chip_size)
		deleteat!(net.pins, findfirst(net.pins .== closest_pair[2]));
		push!(ordering, closest_pair[2])
		bb = GenerateMinimumBoundingBox(closest_pair, chip_size)
	end
	append!(net.pins, ordering)
end

function Greedy(chip::Chip, start::T, target::T)::Vector{BitSet} where T <: Integer
	
    frontier = BinaryMinHeap{Tuple{UInt16, T}}()
    # sizehint!(frontier, max(chip.size[1], chip.size[2])>>2)
    push!(frontier, (0, start))
	
	backtrace = DefaultDict{T, T}(T(0))
	backtrace[start] = T(0)
		
    while !isempty(frontier)

        (current_cost, current_state) = pop!(frontier)
	
        if current_state == target
			# Decrement capacity from all used edges
            return Backtrack!(start, target, backtrace, chip)
        end

		n = neighbors(chip.graph, current_state)
        # deleteat!(n, findfirst(n .== previous_state))
        @inbounds for neighbor in n
			# edge = BitSet((current_state, neighbor))
            @inbounds if backtrace[neighbor] == T(0)
				cost = CalculateDistance(current_state, target, chip.size)
                push!(frontier, (cost, neighbor))
				@inbounds backtrace[neighbor] = current_state
            end
        end
    end
	error("Could not route path")
	return [(T(0), T(0))]

end

function AStar(chip::Chip, start::T, target::T)::Vector{BitSet} where T <: Integer
	
    frontier = BinaryMinHeap{Tuple{UInt32, T}}()
    push!(frontier, (0, start))
	
	backtrace = Dict{T, T}()
	backtrace[start] = T(0)
    cost_so_far = DefaultDict{T, UInt32}(typemax(T))
	# max_frontier_size = 0
    while !isempty(frontier)

        (current_cost, current_state) = pop!(frontier)
	
        if current_state == target
			# Decrement capacity from all used edges
			# print("Frontier got to ", max_frontier_size, " entries and a ")
            return Backtrack!(start, target, backtrace, chip)
        end

		n = neighbors(chip.graph, current_state)

        @inbounds for neighbor in n
			edge = get!(chip.capacities, BitSet((current_state, neighbor)), EdgeData(chip.default_capacity, UInt16(0), convert(UInt8,1)))
			edge_cost = convert(UInt32, max(Int16(@atomic edge.used_capacity) - edge.max_capacity, 1))
			cost = current_cost + edge_cost
			h = CalculateDistance(current_state, target, chip.size)
            @inbounds if cost_so_far[neighbor] > cost
                push!(frontier, (cost + h, neighbor))
                cost_so_far[neighbor] = cost
				backtrace[neighbor] = current_state
            end
        end
    end
	error("Could not route path")
	return [(T(0), T(0))]

end

function CalculateCosts!(nets::Vector{Net}, capacities::Dict{BitSet, EdgeData})

	for net in nets
		cost::UInt32 = 0
		for edge in net.route[]
			ed = capacities[edge]
			overflow = max(ed.used_capacity - ed.max_capacity, 0)
			cost += overflow * ed.overflow_history
		end
		net.route_cost[] = cost
	end
	
	for edge in values(capacities)
		edge.overflow_history += (edge.used_capacity - edge.max_capacity) > 0
	end
end

function RouteChip(chip::Chip)

	initial_time = round(Int64, time())
	
	@inbounds for net in chip.nets
		route = Set{BitSet}()
		# Order pins in nets by net decomposition
		if use_net_decomp == true
			OrderNet!(net, chip.size)
		end
		# Do initial route for all nets
		@inbounds for i in range(1, length=length(net.pins) - 1)
			path = Greedy(chip, net.pins[i], net.pins[i+1])
			union!(route, path)
		end
		net.route[] = route
	end
	
	if use_net_decomp == false && use_net_ordering == false
		return
	end
	println("Begin RRR")
	# Rip up and ReRoute
	while (round(Int64, time()) - initial_time < 900)
		# Calculate costs of net solutions
		if use_net_ordering == true
			CalculateCosts!(chip.nets, chip.capacities)
			# Sort Nets by this
			sort!(chip.nets, by=net->net.route_cost[], rev=true)
		end
		
		@inbounds @threads for net in chip.nets
			@inbounds for edge in net.route[]
				current_edge = chip.capacities[edge]
				@atomic current_edge.used_capacity -= UInt16(1)
			end
			route = Set{BitSet}()
			# Reroute net
			@inbounds for i in range(1, length=length(net.pins) - 1)
				path = AStar(chip, net.pins[i], net.pins[i+1])
				union!(route, path)
			end
			net.route[] = route
		end
		println("RRR time ", round(Int64, time()) - initial_time)
	end
end


@inline function PrintEdge(io::IO, edge::BitSet, chip_size::Tuple{T, T})::Nothing where T <: Integer
	vedge = convert.(T, collect(edge))
	(x₁, y₁) = ConvertNodeToPoint(vedge[1], chip_size)
	(x₂, y₂) = ConvertNodeToPoint(vedge[2], chip_size)
	println(io, "(", x₁, ",", y₁, ")-(", x₂, ",", y₂, ")")
end

function PrintChip(filename::String, nets::Vector{Net}, chip_size::Tuple{T, T}) where T <: Integer
	sort!(nets, by=x->x.id)
	open(filename, "w", ) do out
		for net in nets
			println(out, "n",  string(net.id))
			for segment in net.route[]
				PrintEdge(out, segment, chip_size)
			end
			println(out, "!")
		end
	end
end

function julia_main()::Cint
    try
		input_file_name = ARGS[1]
		output_file_name = ARGS[2]
		if length(ARGS) == 3
			setting = parse(Bool, ARGS[3][4])
			if ARGS[3][2] == 'n'
				global use_net_ordering = setting
			elseif ARGS[3][2] == 'd'
				global use_net_decomp = setting
			end
		elseif length(ARGS) == 4
			setting1 = parse(Bool, ARGS[3][4])
			setting2 = parse(Bool, ARGS[4][4])

			if ARGS[3][2] == 'n'
				global use_net_decomp = setting2
				global use_net_ordering = setting1
			else
				global use_net_decomp = setting1
				global use_net_ordering = setting2
			end
		end
        chip = Parse(input_file_name)
        RouteChip(chip)
		
        PrintChip(output_file_name, chip.nets, chip.size)
    catch
        Base.invokelatest(Base.display_error, Base.catch_stack())
        return 1
    end
    return 0

end

if abspath(PROGRAM_FILE) == @__FILE__
    julia_main()
end

end