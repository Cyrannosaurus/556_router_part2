module Router
using DataStructures, Graphs, StaticArrays, Base.Threads

# primitive type edge <: Unsigned 64 end

struct Net
	id::UInt32
	pins :: Vector{UInt32}
	pin_pairs :: Vector{SVector{2, UInt32}}
	route_cost :: Base.Ref{UInt32}
	route :: Base.Ref{Set{UInt64}}
end

mutable struct EdgeData
	max_capacity :: UInt8
	@atomic used_capacity :: UInt16
	overflow_history :: UInt8
end

struct Chip
	size :: Tuple{UInt32, UInt32}
	default_capacity :: UInt8
	num_nets :: UInt32
	graph :: SimpleGraph{UInt32}
	capacities :: Dict{UInt64, EdgeData}
	nets :: Vector{Net}
end

function GenerateRectangularGraph(chip_size::Tuple{T, T})::SimpleGraph{T} where T <: Integer
	g = SimpleGraph(chip_size[1] * chip_size[2])
	# Add horizontal edges
	current_position = 2
	for _ in 2:chip_size[2]+1
		for _ in 1:chip_size[1]-1
			add_edge!(g, current_position, current_position-1)
			current_position += 1
		end
		current_position+=1
	end

	# Add vertical edges
	current_position = 1
	for _ in 1:chip_size[1] 
		for _ in 1:chip_size[2]-1
			@inbounds add_edge!(g, current_position, current_position + chip_size[1])
			current_position+=1
		end
	end
	g
end

@inline function PairPoints(p₁::UInt32, p₂::UInt32)::UInt64
	return convert(UInt64, max(p₁, p₂))^2 +  min(p₁, p₂)
end

@inline function UnPair(pair::UInt64)::Tuple{UInt32, UInt32}
	s = floor(sqrt(pair))
	return (pair - s^2, s)
end

@inline function ParseEdgeCapacity(edge_definition::Vector{T}, chip_size::Tuple{T, T})::UInt64 where T <: Integer
	@inbounds p₁ = edge_definition[1] + edge_definition[2] * chip_size[1]
	@inbounds p₂ = edge_definition[3] + edge_definition[4] * chip_size[1]
	return PairPoints(p₁, p₂)
end



function Parse(filename::String)::Chip
	lines = readlines(filename)
	
	chip_size = Tuple(parse.(UInt32, split(lines[1])[2:3]))
	default_capacity = parse(UInt8, split(lines[2])[2])
	num_nets = parse(UInt32, split(lines[3])[3])
	capacities = Dict{UInt64, EdgeData}()
	
	nets = Vector{Net}()
	num_pins :: Int32 = -1
	net = nothing
	capacities_start_index = 0
	
	@inbounds for (index, line) ∈ enumerate(view(lines, 4:length(lines)))
		split_line = split(line)

		# Is the first character an 'n' and the second character a number?
		integers = BitSet(48:57)
		if split_line[1][1] == 'n' && Int(split_line[1][2]) ∈ integers
			if num_pins == 0
				push!(nets, net)
			end
			num_pins = parse(Int32, split_line[2])
			net = Net(parse(UInt32,split_line[1][2:end]), Vector{UInt32}(), Vector{SVector{2, UInt32}}(), UInt32(0), Ref{Set{UInt64}}())
			continue
		end
		
		if num_pins > 0
			point = (parse(UInt32, split_line[1]), parse(UInt32, split_line[2]))
			push!(net.pins, ConvertPointToNode(point, chip_size))
		elseif num_pins == 0
			push!(nets, net)
		end
		if length(split_line) == 1
			capacities_start_index = index + 4
		end
		num_pins -= 1
	end
	for line ∈ view(lines, capacities_start_index:length(lines))
		split_line = parse.(UInt32, split(line))
		capacities[ParseEdgeCapacity(split_line, chip_size)] = EdgeData(split_line[end], split_line[end], convert(UInt8,1))
	end
	graph = GenerateRectangularGraph(chip_size)
	return Chip(chip_size, default_capacity, num_nets, graph, capacities, nets)
end

function Backtrack!(start::T, target::T, trace::AbstractDict{T,T}, chip::Chip):: Vector{UInt64} where T <: Integer

	path = Vector{UInt64}()
	current = target

	@inbounds while current != start
		used_edge = PairPoints(current, trace[current])
		edge = get!(chip.capacities, used_edge, EdgeData(chip.default_capacity, UInt16(0), convert(UInt8,1)))
		@atomic edge.used_capacity += UInt16(1)
		push!(path, used_edge)
		current = trace[current]
	end

	return path
end

function CalculateDistance(current::T, target::T, chip_size::Tuple{T, T})::UInt16 where T <: Integer
	c = convert.(Int, fldmod(current - T(1), chip_size[1]))
	t = convert.(Int, fldmod(target - T(1), chip_size[1]))
	return sum(abs.(c .- t))
end

function CostEstimate(current::T, target::T, chip_size::Tuple{T, T})::UInt16 where T <: Integer
	c = convert.(Int, fldmod(current - T(1), chip_size[1]))
	t = convert.(Int, fldmod(target - T(1), chip_size[1]))
	return floor(sqrt(sum((c .- t).^2)))
end

@inline function ConvertPointToNode(p::Tuple{T,T}, chip_size::Tuple{T,T})::T where T <: Integer
	return @inbounds p[1] + T(1) + p[2] * chip_size[1]
end

@inline function ConvertNodeToPoint(node::T, chip_size::Tuple{T,T})::Tuple{T, T} where T <: Integer
	@inbounds (x, y) = fldmod(node - T(1), chip_size[1])
	(y, x)
end

function ClosestPair(subnet₁::Vector{T}, subnet₂::Vector{T}, chip_size::Tuple{T,T})::SVector{2, T} where T <: Integer
	
	best = typemax(T)
	best_pair = SA[0,0]
	
	for p₁ in subnet₁
		for p₂ in subnet₂
			if p₁ == p₂
				continue
			end
			distance = CalculateDistance(p₁, p₂, chip_size)
			if (distance < best)
				best = distance
				best_pair = SA[p₁, p₂]
			end
		end
	end

	return best_pair
end
# Can this be done without converting to 2D?
# Can this be done without converting to 2D?
function GenerateMinimumBoundingBox(points::SVector{2, T}, chip_size::Tuple{T,T})::Vector{T} where T <:Integer
	(x₁, y₁) = ConvertNodeToPoint(points[1], chip_size)
	(x₂, y₂) = ConvertNodeToPoint(points[2], chip_size)

	p₃ = ConvertPointToNode((x₁, y₂), chip_size)
	p₄ = ConvertPointToNode((x₂, y₁), chip_size)
	return unique((points[1], points[2], p₃, p₄))
end


# Return the sorted order of pins
# TODO: Make copy instead of doing inplace
# This means change Net to reference pins
# function OrderNet!(net::Net, chip_size::Tuple{T,T}) where T <: Integer
# 	start = ClosestPair(net.pins, net.pins, chip_size)[1]
# 	ordering = Vector{T}()
# 	sizehint!(ordering, length(net.pins))
# 	push!(ordering, start)
# 	deleteat!(net.pins, findfirst(net.pins .== start))
# 	bb = [start]
	
# 	@inbounds for _ in 1:length(net.pins)
# 		closest_pair = ClosestPair(bb, net.pins, chip_size)
# 		deleteat!(net.pins, findfirst(net.pins .== closest_pair[2]))
# 		push!(ordering, closest_pair[2])
# 		bb = GenerateMinimumBoundingBox(closest_pair, chip_size)
# 	end
# 	append!(net.pins, ordering)
# end
function OrderNet!(net::Net, chip_size::Tuple{T,T}) where T <: Integer
	included = Vector{T}()
	sizehint!(included, length(net.pins))
	excluded = copy(net.pins)
	pairs = Vector{SVector{2, UInt32}}()
	sizehint!(pairs, length(net.pins))

	start = ClosestPair(excluded, excluded, chip_size)
	push!(pairs, start)
	append!(included, start)
	deleteat!(excluded, in.(excluded, Ref(start)))

	for _ in 1:length(excluded)
		pair = ClosestPair(included, excluded, chip_size)
		push!(pairs, pair)
		deleteat!(excluded, findfirst(excluded .== pair[2]))
		push!(included, pair[2])
	end
	append!(net.pin_pairs, pairs)
	return
end

function Greedy(chip::Chip, start::T, target::T)::Vector{UInt64} where T <: Integer
	
    frontier = BinaryMinHeap{Tuple{UInt16, T}}()
    # sizehint!(frontier, max(chip.size[1], chip.size[2])>>2)
    push!(frontier, (0, start))
	
	backtrace = DefaultDict{T, T}(T(0))
	backtrace[start] = T(0)
		
    while !isempty(frontier)

        (current_cost, current_state) = pop!(frontier)
	
        if current_state == target
			# Decrement capacity from all used edges
            return Backtrack!(start, target, backtrace, chip)
        end

		n = neighbors(chip.graph, current_state)

        @inbounds for neighbor in n
            @inbounds if backtrace[neighbor] == T(0)
				cost = CalculateDistance(current_state, target, chip.size)
                push!(frontier, (cost, neighbor))
				@inbounds backtrace[neighbor] = current_state
            end
        end
    end
	error("Could not route path")
	return [(T(0), T(0))]

end

function AStar(chip::Chip, start::T, target::T)::Vector{UInt64} where T <: Integer
	
    frontier = BinaryMinHeap{Tuple{UInt32, T}}()
    push!(frontier, (0, start))
	
	backtrace = Dict{T, T}()
	backtrace[start] = T(0)
    cost_so_far = DefaultDict{T, UInt32}(typemax(T))
	# max_frontier_size = 0
    while !isempty(frontier)

        (current_cost, current_state) = pop!(frontier)
	
        if current_state == target
			# Decrement capacity from all used edges
			# print("Frontier got to ", max_frontier_size, " entries and a ")
            return Backtrack!(start, target, backtrace, chip)
        end

		n = neighbors(chip.graph, current_state)

        @inbounds for neighbor in n
			edge = get!(chip.capacities, PairPoints(current_state, neighbor), EdgeData(chip.default_capacity, UInt16(0), convert(UInt8,1)))
			edge_cost = convert(UInt32, max(Int16(@atomic edge.used_capacity) - edge.max_capacity, 1))
			cost = current_cost + edge_cost
			h = CostEstimate(neighbor, target, chip.size)
            @inbounds if cost_so_far[neighbor] > cost
                push!(frontier, (cost + h, neighbor))
                cost_so_far[neighbor] = cost
				backtrace[neighbor] = current_state
            end
        end
    end
	error("Could not route path")
	return [(T(0), T(0))]

end

function CalculateCosts!(nets::Vector{Net}, capacities::Dict{UInt64, EdgeData})

	for net in nets
		cost::UInt32 = 0
		for edge in net.route[]
			ed = capacities[edge]
			overflow = max(convert(Int32, ed.used_capacity) - ed.max_capacity, 0)
			cost += overflow * ed.overflow_history
		end
		net.route_cost[] = cost
	end
	
	for edge in values(capacities)
		edge.overflow_history += (convert(Int32, edge.used_capacity) - edge.max_capacity) > 0
	end
end

function RouteChip(chip::Chip)

	initial_time = round(Int64, time())
	
	@inbounds for net in chip.nets
		route = Set{UInt64}()
		# Order pins in nets by net decomposition
		# And do initial route for all nets
		OrderNet!(net, chip.size)
		@inbounds for i in 1:length(net.pin_pairs)
			path = Greedy(chip, net.pin_pairs[i][1], net.pin_pairs[i][2])
			union!(route, path)
		end
		net.route[] = route
	end
	println("Begin RRR")
	# Rip up and ReRoute
	for _ in 1:3
		# Calculate costs of net solutions
		CalculateCosts!(chip.nets, chip.capacities)
		# Sort Nets by this
		sort!(chip.nets, by=net->net.route_cost[], rev=true)

		@inbounds for net in chip.nets
			@inbounds for edge in net.route[]
				current_edge = chip.capacities[edge]
				@atomic current_edge.used_capacity -= UInt16(1)
			end
			route = Set{UInt64}()
			# Reroute net
			@inbounds for i in 1:length(net.pin_pairs)
				path = AStar(chip, net.pin_pairs[i][1], net.pin_pairs[i][2])
				union!(route, path)
			end
			net.route[] = route
		end

		println("RRR time ", round(Int64, time()) - initial_time)
	end
end


@inline function PrintEdge(io::IO, edge::UInt64, chip_size::Tuple{T, T})::Nothing where T <: Integer
	vedge = UnPair(edge)
	(x₁, y₁) = ConvertNodeToPoint(vedge[1], chip_size)
	(x₂, y₂) = ConvertNodeToPoint(vedge[2], chip_size)
	println(io, "(", x₁, ",", y₁, ")-(", x₂, ",", y₂, ")")
end

function PrintChip(filename::String, nets::Vector{Net}, chip_size::Tuple{T, T}) where T <: Integer
	sort!(nets, by=x->x.id)
	open(filename, "w", ) do out
		for net in nets
			println(out, "n",  string(net.id))
			for segment in net.route[]
				PrintEdge(out, segment, chip_size)
			end
			println(out, "!")
		end
	end
end

function julia_main()::Cint
    try
		input_file_name = ARGS[1]
		output_file_name = ARGS[2]
        chip = Parse(input_file_name)
        RouteChip(chip)
		
        PrintChip(output_file_name, chip.nets, chip.size)
    catch
        Base.invokelatest(Base.display_error, Base.catch_stack())
        return 1
    end
    return 0

end

if abspath(PROGRAM_FILE) == @__FILE__
    julia_main()
end

end